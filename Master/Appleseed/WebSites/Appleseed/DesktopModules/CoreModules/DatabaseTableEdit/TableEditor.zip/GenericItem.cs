using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TripleASP.SiteAdmin.TableEditorControl
{
	/// <summary>
	/// Summary description for GenericItemTemplateColumn.
	/// </summary>
	public class GenericItemTemplateColumn : ITemplate
	{
		private string column;
		private int maxlengthstring = -1;

		public GenericItemTemplateColumn(string column, int maxlengthstring)
		{
			this.column = column;
			this.maxlengthstring = maxlengthstring;
		}
		public GenericItemTemplateColumn(string column)
		{
			this.column = column;
		}
		public void InstantiateIn(Control container)
		{
			Label l = new Label();
			
			l.DataBinding += new EventHandler(this.BindData);

			container.Controls.Add(l);
		
		}

		public void BindData(object sender, EventArgs e)
		{
			Label l = (Label) sender;
			DataGridItem container = (DataGridItem) l.NamingContainer;
			string s = HttpContext.Current.Server.HtmlEncode(((DataRowView) container.DataItem)[column].ToString());
			if(maxlengthstring > -1 && s.Length > maxlengthstring)
			{
				l.Text = s.Substring(0, maxlengthstring) + "...";
			}
			else
			{
				l.Text = s;
			}
		}
	}
}
