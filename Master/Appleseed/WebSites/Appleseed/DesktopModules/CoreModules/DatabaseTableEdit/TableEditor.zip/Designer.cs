using System;
using System.IO;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.Design;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Collections;
using System.Diagnostics;
using System.Text;

namespace TripleASP.SiteAdmin.TableEditorControl
{
	/// <summary>
	/// Summary description for Designer.
	/// </summary>
	public class TableEditorControlDesigner : ControlDesigner
	{
		private TableEditor _tableeditor ;
		public TableEditorControlDesigner()
		{

		}


		public override bool AllowResize
		{
			get	{return false;}
		}
		
		public override void Initialize(IComponent component)
		{
			_tableeditor = (TableEditor)component;
			base.Initialize(component);
		}

		public override string GetDesignTimeHtml()
		{
			StringWriter sw = new StringWriter();
			HtmlTextWriter htw = new HtmlTextWriter(sw);
			Table t = new Table();
			t.BorderColor = Color.FromArgb(242,242,242);
			t.BackColor = Color.Blue;
			t.BorderStyle = BorderStyle.Solid;
			t.Rows.Add(AddRow("TripleASP.Net TableEditor"));
			t.Rows.Add(AddRow("MaxStringLength", _tableeditor.MaxStringLength.ToString()));
			t.Rows.Add(AddRow("ConfigConnectionString", _tableeditor.ConfigConnectionString));
			t.Rows.Add(AddRow("ConnectionString", _tableeditor.ConnectionString));
			t.Rows.Add(AddRow("Table", _tableeditor.Table));
			t.Rows.Add(AddRow("AllowDeleting", _tableeditor.AllowDeleting.ToString()));
			t.Rows.Add(AddRow("AllowEditing", _tableeditor.AllowEditing.ToString()));
			t.RenderControl(htw);
			return sw.ToString();
		}

		private TableRow AddRow(string text, string property)
		{
			TableCell c = new TableCell();
			TableRow r = new TableRow();
			r.BackColor = Color.White;
			c.Text = text;
			c.ForeColor = Color.Black;
			c.Font.Bold = true;
			r.Cells.Add(c);
			c = new TableCell();
			if(property == null)
			{ property = "null";}
			c.Text = property;
			c.Font.Bold = false;
			c.ForeColor = Color.Black;
			r.Cells.Add(c);
			return r;
			
		}

		private TableRow AddRow(string text)
		{
			TableCell c = new TableCell();
			TableRow r = new TableRow();
			r.BackColor = Color.Blue;
			c.ColumnSpan = 2;
			c.Text = text;
			c.ForeColor = Color.White;
			c.HorizontalAlign = HorizontalAlign.Center;
			c.VerticalAlign = VerticalAlign.Middle;
			c.Font.Bold = true;
			r.Cells.Add(c);
			return r;

		}


	}
}
